from zope.interface import Interface

class IFeedDisplay(Interface):
    """
    Feed Display view interface
    """

    pass


