"""Common configuration constants
"""

PROJECTNAME = 'agsci.apdfeeds'

ADD_PERMISSIONS = {
    # -*- extra stuff goes here -*-
}
